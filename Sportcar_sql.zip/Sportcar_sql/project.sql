-- =====================================================
-- LUXURY SPORTS CARS SQL PROJECT
-- Author: Amaia Gil
-- Database: PostgreSQL
-- =====================================================

-- =========================================
-- MASTER PIPELINE EXECUTION
-- =========================================

-- STAGING
\i staging/stg_cars.sql

-- CORE
\i core/tables.sql

-- SEMANTIC
\i semantic/vw_first_second_third.sql

-- ANALYSIS
\i analysis/analysis_queries.sql

-- =====================================================
-- STAGING LAYER
-- =====================================================

-- preview de los datos
SELECT * 
FROM staging_cars 
LIMIT 10;


-- =====================================================
-- DATA QUALITY CHECKS
-- =====================================================

-- total de filas
SELECT COUNT(*) AS total_rows 
FROM staging_cars;

-- valores nulos en columnas clave
SELECT *
FROM staging_cars
WHERE make IS NULL
   OR model IS NULL
   OR price IS NULL;

-- duplicados por marca + modelo (más robusto)
SELECT make, model, COUNT(*) AS duplicates
FROM staging_cars
GROUP BY make, model
HAVING COUNT(*) > 1;

-- potencia con símbolos
SELECT DISTINCT horsepower
FROM staging_cars
WHERE horsepower LIKE '%+%';

-- precios con formato incorrecto
SELECT DISTINCT price
FROM staging_cars
WHERE price LIKE '%,%';


-- =====================================================
-- CORE LAYER
-- =====================================================

DROP TABLE IF EXISTS prices;
DROP TABLE IF EXISTS cars;
DROP TABLE IF EXISTS brands;


-- DIMENSION: brands
CREATE TABLE brands (
    brand_id SERIAL PRIMARY KEY,
    brand_name TEXT NOT NULL
);

INSERT INTO brands (brand_name)
SELECT DISTINCT make
FROM staging_cars
WHERE make IS NOT NULL;


-- FACT: cars
CREATE TABLE cars (
    car_id SERIAL PRIMARY KEY,
    brand_id INT NOT NULL,
    model TEXT NOT NULL,
    year INT NOT NULL,
    engine_size NUMERIC,
    horsepower INT,
    torque INT,
    acceleration NUMERIC,
    FOREIGN KEY (brand_id) REFERENCES brands(brand_id)
);

INSERT INTO cars (
    brand_id,
    model,
    year,
    engine_size,
    horsepower,
    torque,
    acceleration
)
SELECT
    b.brand_id,
    s.model,
    s.year::INT,
    NULLIF(s.engine_size, '')::NUMERIC,
    NULLIF(REPLACE(s.horsepower, '+', ''), '')::INT,
    NULLIF(REPLACE(s.torque, ',', ''), '')::INT,
    NULLIF(s.acceleration, '')::NUMERIC
FROM staging_cars s
JOIN brands b
    ON s.make = b.brand_name
WHERE s.model IS NOT NULL;


-- FACT: prices
CREATE TABLE prices (
    price_id SERIAL PRIMARY KEY,
    car_id INT NOT NULL,
    price NUMERIC NOT NULL,
    FOREIGN KEY (car_id) REFERENCES cars(car_id)
);

INSERT INTO prices (car_id, price)
SELECT
    c.car_id,
    REPLACE(s.price, ',', '')::NUMERIC
FROM staging_cars s
JOIN cars c
    ON s.model = c.model
    AND s.make = (
        SELECT brand_name
        FROM brands
        WHERE brand_id = c.brand_id
    )
WHERE s.price IS NOT NULL;


-- índices (nivel pro)
CREATE INDEX idx_cars_brand_id ON cars(brand_id);
CREATE INDEX idx_prices_car_id ON prices(car_id);


-- =====================================================
-- SEMANTIC LAYER
-- =====================================================

-- precio medio por marca
CREATE OR REPLACE VIEW vw_avg_price_by_brand AS
SELECT
    b.brand_name,
    ROUND(AVG(p.price), 2) AS avg_price
FROM brands b
JOIN cars c ON b.brand_id = c.brand_id
JOIN prices p ON c.car_id = p.car_id
GROUP BY b.brand_name;


-- resumen de rendimiento
CREATE OR REPLACE VIEW vw_brand_performance_summary AS
SELECT
    b.brand_name,
    ROUND(AVG(p.price), 2) AS avg_price,
    ROUND(AVG(c.horsepower), 2) AS avg_horsepower,
    COUNT(c.car_id) AS total_models
FROM brands b
JOIN cars c ON b.brand_id = c.brand_id
JOIN prices p ON c.car_id = p.car_id
WHERE c.horsepower IS NOT NULL
GROUP BY b.brand_name;


-- ranking de potencia
CREATE OR REPLACE VIEW vw_most_powerful_cars AS
SELECT
    b.brand_name,
    c.model,
    c.horsepower,
    RANK() OVER (ORDER BY c.horsepower DESC) AS power_rank
FROM cars c
JOIN brands b ON c.brand_id = b.brand_id
WHERE c.horsepower IS NOT NULL;


-- =====================================================
-- ANALYTICAL QUERIES
-- =====================================================

-- 1. modelos por marca
SELECT b.brand_name, COUNT(*) AS total_models
FROM cars c
JOIN brands b ON c.brand_id = b.brand_id
GROUP BY b.brand_name
ORDER BY total_models DESC;

-- 2. potencia media
SELECT b.brand_name, ROUND(AVG(c.horsepower),2) AS avg_hp
FROM cars c
JOIN brands b ON c.brand_id = b.brand_id
WHERE c.horsepower IS NOT NULL
GROUP BY b.brand_name
ORDER BY avg_hp DESC;

-- 3. precio medio por año
SELECT c.year, ROUND(AVG(p.price),2) AS avg_price
FROM cars c
JOIN prices p ON c.car_id = p.car_id
GROUP BY c.year
ORDER BY c.year;

-- 4. coches por año
SELECT year, COUNT(*) AS total_cars
FROM cars
GROUP BY year
ORDER BY year;

-- 5. top coches caros
SELECT b.brand_name, c.model, p.price
FROM cars c
JOIN prices p ON c.car_id = p.car_id
JOIN brands b ON c.brand_id = b.brand_id
ORDER BY p.price DESC
LIMIT 10;

-- 6. ranking potencia por marca
SELECT
    b.brand_name,
    c.model,
    c.horsepower,
    RANK() OVER (
        PARTITION BY b.brand_name
        ORDER BY c.horsepower DESC
    ) AS power_rank
FROM cars c
JOIN brands b ON c.brand_id = b.brand_id
WHERE c.horsepower IS NOT NULL;

-- 7. potencia superior a la media
WITH avg_hp AS (
    SELECT AVG(horsepower) AS avg_hp FROM cars
)
SELECT model, horsepower
FROM cars
WHERE horsepower > (SELECT avg_hp FROM avg_hp);

-- 8. precio superior a la media
WITH avg_price AS (
    SELECT AVG(price) AS avg_price FROM prices
)
SELECT b.brand_name, c.model, p.price
FROM cars c
JOIN prices p ON c.car_id = p.car_id
JOIN brands b ON c.brand_id = b.brand_id
WHERE p.price > (SELECT avg_price FROM avg_price);

-- 9. precio medio marca-año
SELECT b.brand_name, c.year, ROUND(AVG(p.price),2) AS avg_price
FROM brands b
JOIN cars c ON b.brand_id = c.brand_id
JOIN prices p ON c.car_id = p.car_id
GROUP BY b.brand_name, c.year
ORDER BY b.brand_name, c.year;

-- 10. modelos únicos
SELECT b.brand_name, COUNT(DISTINCT c.model) AS unique_models
FROM cars c
JOIN brands b ON c.brand_id = b.brand_id
GROUP BY b.brand_name
ORDER BY unique_models DESC;


-- =====================================================
-- TRANSACTION
-- =====================================================

BEGIN;

UPDATE prices
SET price = price
WHERE price IS NOT NULL;

COMMIT;

-- =========================================
-- FUNCTION: convertir precio limpio
-- =========================================

CREATE OR REPLACE FUNCTION clean_price(price_text TEXT)
RETURNS NUMERIC AS $$
BEGIN
    RETURN REPLACE(price_text, ',', '')::NUMERIC;
END;
$$ LANGUAGE plpgsql;