-- =========================================
-- CORE LAYER
-- =========================================
DROP TABLE IF EXISTS prices;
DROP TABLE IF EXISTS cars;
DROP TABLE IF EXISTS brands;

-- 1. Crear tabla brands
CREATE TABLE brands (
    brand_id SERIAL PRIMARY KEY,
    brand_name TEXT
);

-- Insertar marcas únicas
INSERT INTO brands (brand_name)
SELECT DISTINCT make
FROM staging_cars;


-- 2. Crear tabla cars
CREATE TABLE cars (
    car_id SERIAL PRIMARY KEY,
    brand_id INT,
    model TEXT,
    year TEXT,
    engine_size TEXT,
    horsepower TEXT,
    torque TEXT,
    acceleration TEXT,
    FOREIGN KEY (brand_id) REFERENCES brands(brand_id)
);

-- Insertar coches
INSERT INTO cars (
    brand_id,
    model,
    year,
    engine_size,
    horsepower,
    torque,
    acceleration
)
SELECT
    b.brand_id,
    s.model,
    s.year,
    s.engine_size,
    s.horsepower,
    s.torque,
    s.acceleration
FROM staging_cars s
JOIN brands b
    ON s.make = b.brand_name;


-- 3. Crear tabla prices
CREATE TABLE prices (
    price_id SERIAL PRIMARY KEY,
    car_id INT,
    price TEXT,
    FOREIGN KEY (car_id) REFERENCES cars(car_id)
);

-- Insertar precios
INSERT INTO prices (car_id, price)
SELECT
    c.car_id,
    s.price
FROM staging_cars s
JOIN cars c
    ON s.model = c.model;

    -- =========================================
-- CORE LAYER
-- =========================================

-- 1. Crear tabla brands
CREATE TABLE brands (
    brand_id SERIAL PRIMARY KEY,
    brand_name TEXT
);

-- Insertar marcas únicas
INSERT INTO brands (brand_name)
SELECT DISTINCT make
FROM staging_cars;


-- 2. Crear tabla cars
CREATE TABLE cars (
    car_id SERIAL PRIMARY KEY,
    brand_id INT,
    model TEXT,
    year TEXT,
    engine_size TEXT,
    horsepower TEXT,
    torque TEXT,
    acceleration TEXT,
    FOREIGN KEY (brand_id) REFERENCES brands(brand_id)
);

-- Insertar coches
INSERT INTO cars (
    brand_id,
    model,
    year,
    engine_size,
    horsepower,
    torque,
    acceleration
)
SELECT
    b.brand_id,
    s.model,
    s.year,
    s.engine_size,
    s.horsepower,
    s.torque,
    s.acceleration
FROM staging_cars s
JOIN brands b
    ON s.make = b.brand_name;


-- 3. Crear tabla prices
CREATE TABLE prices (
    price_id SERIAL PRIMARY KEY,
    car_id INT,
    price TEXT,
    FOREIGN KEY (car_id) REFERENCES cars(car_id)
);

-- Insertar precios
INSERT INTO prices (car_id, price)
SELECT
    c.car_id,
    s.price
FROM staging_cars s
JOIN cars c
    ON s.model = c.model;