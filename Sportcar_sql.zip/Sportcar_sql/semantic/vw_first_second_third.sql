SELECT * FROM vw_avg_price_by_brand;
SELECT * FROM vw_most_powerful_cars;
SELECT * FROM vw_brand_performance_summary;
