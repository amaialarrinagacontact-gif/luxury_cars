-- =========================================
-- EXPLORATORY / ANALYTICAL QUERIES
-- =========================================

-- 1. Número de modelos por marca
SELECT
    b.brand_name,
    COUNT(*) AS total_models
FROM cars c
JOIN brands b
    ON c.brand_id = b.brand_id
GROUP BY b.brand_name
ORDER BY total_models DESC;


-- 2. Potencia media por marca
SELECT
    b.brand_name,
    AVG(REPLACE(c.horsepower,'+','')::NUMERIC) AS avg_hp
FROM cars c
JOIN brands b
    ON c.brand_id = b.brand_id
GROUP BY b.brand_name
ORDER BY avg_hp DESC;


-- 3. Precio medio por año
SELECT
    c.year,
    AVG(REPLACE(p.price, ',', '')::NUMERIC) AS avg_price
FROM cars c
JOIN prices p
    ON c.car_id = p.car_id
GROUP BY c.year
ORDER BY c.year;


-- 4. Número de coches por año
SELECT
    year,
    COUNT(*) AS total_cars
FROM cars
GROUP BY year
ORDER BY year;


-- 5. Coches más caros
SELECT
    c.model,
    p.price
FROM cars c
JOIN prices p
    ON c.car_id = p.car_id
ORDER BY REPLACE(p.price, ',', '')::NUMERIC DESC
LIMIT 10;


-- 6. Ranking de potencia por marca
SELECT
    b.brand_name,
    c.model,
    REPLACE(c.horsepower,'+','')::INT AS horsepower,
    RANK() OVER (
        PARTITION BY b.brand_name
        ORDER BY REPLACE(c.horsepower,'+','')::INT DESC
    ) AS power_rank
FROM cars c
JOIN brands b
    ON c.brand_id = b.brand_id;


-- 7. Coches con potencia superior a la media (CTE)
WITH avg_hp AS (
    SELECT
        AVG(REPLACE(horsepower,'+','')::NUMERIC) AS avg_hp
    FROM cars
)
SELECT
    model,
    horsepower
FROM cars
WHERE REPLACE(horsepower,'+','')::NUMERIC >
      (SELECT avg_hp FROM avg_hp);


-- 8. Coches más caros que la media (CTE)
WITH avg_price AS (
    SELECT
        AVG(REPLACE(price, ',', '')::NUMERIC) AS avg_price
    FROM prices
)
SELECT
    c.model,
    p.price
FROM cars c
JOIN prices p
    ON c.car_id = p.car_id
WHERE REPLACE(p.price, ',', '')::NUMERIC >
      (SELECT avg_price FROM avg_price);


-- 9. Precio medio por marca y año
SELECT
    b.brand_name,
    c.year,
    AVG(REPLACE(p.price, ',', '')::NUMERIC) AS avg_price
FROM brands b
JOIN cars c
    ON b.brand_id = c.brand_id
JOIN prices p
    ON c.car_id = p.car_id
GROUP BY b.brand_name, c.year
ORDER BY b.brand_name;


-- 10. Modelos únicos por marca
SELECT
    b.brand_name,
    COUNT(DISTINCT c.model) AS unique_models
FROM cars c
JOIN brands b
    ON c.brand_id = b.brand_id
GROUP BY b.brand_name
ORDER BY unique_models DESC;